// Mapeamento da area dos topicos e dos title h2 dos posts
const listTopics = document.querySelector('.js-topics');
const topics = document.querySelectorAll('.s-detalhes-post .featured-info-post .info-post-geral .right-content .content-post h2');


if(listTopics) {
  // Criação dos topics HTML por Javascript
  topics.forEach(topic => {
    let listElement = document.createElement('li');
    listTopics.appendChild(listElement);

    let ancorTopic = document.createElement('a');
    ancorTopic.setAttribute('href', '#');
    listElement.appendChild(ancorTopic);

    let textTopic = document.createElement('span');
    textTopic.textContent = topic.textContent;
    ancorTopic.appendChild(textTopic);
  })

  //Mapeamento de todos os links de topics
  const allTopics = document.querySelectorAll('.js-topics li a');
  
  // Ativando o primeiro item dos topicos
  allTopics[0].classList.add('active');

  // funcão que retorna a posicao do elemento
  function offset(el) {
    if (document) {
      const rect = el.getBoundingClientRect()
      const scrollLeft =
        window.pageXOffset || document.documentElement.scrollLeft
      const scrollTop = window.pageYOffset || document.documentElement.scrollTop
      return { top: rect.top + scrollTop, left: rect.left + scrollLeft }
    }
  }

  // Função que da o scroll até a posição do h2 correspondendo
  function handleScrollTop(position) {
    if(document) {
      const topics = document.querySelectorAll('.s-detalhes-post .featured-info-post .info-post-geral .right-content .content-post h2')[position];

      window.scroll({
        behavior: 'smooth',
        left: 0,
        top: offset(topics).top - 110
      })
    }
  }

  // Mapeando e fazer o evento de clique nos topics para dar o scroll conforme o layout
  allTopics.forEach((item, index) => {
    item.addEventListener('click', (event) => {
      event.preventDefault();

      allTopics.forEach(all => {
        all.classList.remove('active');
      })

      item.classList.add('active');

      handleScrollTop(index);
    })
  })
}