# projeto-wireframe
Projeto criado pra apresentar técnicas de Flexbox pelo professor <a href="https://willmoreira.com.br/">Will Moreira</a> mentor do curso <a href="https://codeboost.com.br/">Codeboost</a>.

<img src="./.github/preview.jpg" alt="Foto do projeto">

# Tecnologias Usadas 🚀

 <ul>
    <li>HTML</li>
    <li>CSS</li>
    <li>Javascript</li>
 </ul>

 ## Bibliotecas

<ul>
   <li><a href="https://fonts.google.com/">Google Fonts</a></li>
    <li><a href="https://michalsnik.github.io/aos/">AOS</a></li>
 </ul>




